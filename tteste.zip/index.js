var axios = require('axios');

//exports.handler = async (event) => {
    axios.post('https://cvxcv.free.beeceptor.com', {
        teste : "Apenas um teste"
    })
    .then(f => {
        console.log('Sucesso');
        return true;
    });
//};
